/**
 * Background Script
 * Executa em segundo plano e gerencia a execução de scripts
 */

// Escutar eventos de instalação/atualização
chrome.runtime.onInstalled.addListener(details => {
  console.log('InspectMaker instalado/atualizado:', details.reason);
});

// Escutar eventos de navegação
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // Inicializar scripts quando a página for carregada
    initializeTabScripts(tabId);
  }
});

// Manipulador de mensagens da extensão
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'executeScript') {
    // Executar script em uma aba específica ou na aba ativa
    executeScript(message.script, null)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Manter a conexão aberta para resposta assíncrona
  } else if (message.action === 'getActiveScripts') {
    // Retornar scripts ativos para a aba especificada
    getActiveScripts(sender.tab?.id || null)
      .then(scripts => sendResponse({ success: true, scripts }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  } else if (message.action === 'injectScript') {
    // Injetar um script em todas as abas compatíveis
    injectScript(message.script)
      .then(result => sendResponse({ success: true, result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  } else if (message.action === 'removeInjection') {
    // Remover injeção de um script de todas as abas
    removeInjection(message.scriptId)
      .then(result => sendResponse({ success: true, result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});

/**
 * Inicializa os scripts para uma aba específica
 * @param {number} tabId ID da aba
 */
function initializeTabScripts(tabId) {
  // Enviar mensagem para o content script inicializar
  chrome.tabs.sendMessage(
    tabId,
    { action: 'initializeScripts' },
    response => {
      // Tratamento de erro silencioso, pois o content script pode não estar carregado ainda
      if (chrome.runtime.lastError) {
        console.log(`Tab ${tabId} not ready yet`);
      }
    }
  );
}

/**
 * Executa um script em uma aba específica
 * @param {Object} script O script a ser executado
 * @param {number|null} tabId ID da aba (null para a aba ativa)
 * @returns {Promise<Object>} Resultado da execução
 */
function executeScript(script, tabId) {
  return new Promise((resolve, reject) => {
    if (tabId === null) {
      // Obter a aba ativa
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) {
          reject(new Error('Nenhuma aba ativa encontrada'));
          return;
        }
        executeScriptInTab(script, tabs[0].id)
          .then(resolve)
          .catch(reject);
      });
    } else {
      // Executar na aba especificada
      executeScriptInTab(script, tabId)
        .then(resolve)
        .catch(reject);
    }
  });
}

/**
 * Executa um script em uma aba específica
 * @param {Object} script O script a ser executado
 * @param {number} tabId ID da aba
 * @returns {Promise<Object>} Resultado da execução
 */
function executeScriptInTab(script, tabId) {
  return new Promise((resolve, reject) => {
    // Verificar o ambiente de execução
    if (script.executionEnvironment === 'pc') {
      // Executar no Node.js local
      executeNodeScript(script)
        .then(resolve)
        .catch(reject);
      return;
    }
    
    // Executar no navegador (ambiente padrão)
    chrome.tabs.sendMessage(
      tabId,
      { action: 'executeScript', script },
      response => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        
        if (response && response.success) {
          resolve(response);
        } else {
          reject(new Error('Falha ao executar script na aba'));
        }
      }
    );
  });
}

/**
 * Obtém os scripts ativos em uma aba específica
 * @param {number|null} tabId ID da aba (null para a aba ativa)
 * @returns {Promise<Array>} Lista de scripts ativos
 */
function getActiveScripts(tabId) {
  return new Promise((resolve, reject) => {
    if (tabId === null) {
      // Obter a aba ativa
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) {
          reject(new Error('Nenhuma aba ativa encontrada'));
          return;
        }
        getActiveScriptsFromTab(tabs[0].id)
          .then(resolve)
          .catch(reject);
      });
    } else {
      // Obter scripts da aba especificada
      getActiveScriptsFromTab(tabId)
        .then(resolve)
        .catch(reject);
    }
  });
}

/**
 * Obtém os scripts ativos em uma aba específica
 * @param {number} tabId ID da aba
 * @returns {Promise<Array>} Lista de scripts ativos
 */
function getActiveScriptsFromTab(tabId) {
  return new Promise((resolve, reject) => {
    // Obter todos os scripts armazenados
    chrome.storage.local.get('scripts', data => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
        return;
      }
      
      const scripts = data.scripts || [];
      // Filtrar por scripts ativos
      const activeScripts = scripts.filter(script => script.enabled);
      resolve(activeScripts);
    });
  });
}

/**
 * Injetar um script em todas as abas compatíveis
 * @param {Object} script O script a ser injetado
 * @returns {Promise<Object>} Resultado da injeção
 */
function injectScript(script) {
  return new Promise((resolve, reject) => {
    // Verificar se o script está ativado
    if (!script.enabled) {
      reject(new Error('O script não está ativado. Ative-o nas configurações.'));
      return;
    }
    
    // Obter todas as abas abertas
    chrome.tabs.query({}, (tabs) => {
      if (tabs.length === 0) {
        reject(new Error('Nenhuma aba encontrada'));
        return;
      }
      
      // Contador para acompanhar o progresso
      let successCount = 0;
      let failCount = 0;
      const totalTabs = tabs.length;
      
      // Para cada aba, tenta injetar o script
      tabs.forEach(tab => {
        // Verificar se o script já está marcado para injeção nesta aba
        chrome.tabs.sendMessage(
          tab.id,
          { action: 'injectScript', script },
          response => {
            // Ignorar erros de comunicação (provavelmente o content script não está carregado)
            if (chrome.runtime.lastError) {
              failCount++;
            } else {
              successCount++;
            }
            
            // Se todas as abas foram processadas, resolver a promessa
            if (successCount + failCount === totalTabs) {
              resolve({
                message: `Script preparado para injeção em ${successCount} abas.`,
                successCount,
                failCount
              });
            }
          }
        );
      });
    });
  });
}

/**
 * Remove a injeção de um script de todas as abas
 * @param {number} scriptId ID do script cuja injeção será removida
 * @returns {Promise<Object>} Resultado da remoção
 */
function removeInjection(scriptId) {
  return new Promise((resolve, reject) => {
    // Obter todas as abas abertas
    chrome.tabs.query({}, (tabs) => {
      if (tabs.length === 0) {
        reject(new Error('Nenhuma aba encontrada'));
        return;
      }
      
      // Contador para acompanhar o progresso
      let successCount = 0;
      let failCount = 0;
      const totalTabs = tabs.length;
      
      // Para cada aba, tenta remover o script
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(
          tab.id,
          { action: 'removeInjection', scriptId },
          response => {
            // Ignorar erros de comunicação (provavelmente o content script não está carregado)
            if (chrome.runtime.lastError) {
              failCount++;
            } else {
              successCount++;
            }
            
            // Se todas as abas foram processadas, resolver a promessa
            if (successCount + failCount === totalTabs) {
              resolve({
                message: `Injeção do script removida de ${successCount} abas.`,
                successCount,
                failCount
              });
            }
          }
        );
      });
    });
  });
}

/**
 * Executa um script Node.js via servidor local
 * @param {Object} script O script a ser executado
 * @returns {Promise<Object>} Resultado da execução
 */
function executeNodeScript(script) {
  return new Promise((resolve, reject) => {
    // Obter configurações do servidor local
    chrome.storage.local.get('settings', data => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
        return;
      }
      
      const settings = data.settings || {};
      if (!settings.useLocalHelper) {
        reject(new Error('Servidor local não está ativado nas configurações'));
        return;
      }
      
      const serverPort = settings.localServerPort || 8081;
      const serverUrl = `http://localhost:${serverPort}/execute`;
      
      // Enviar solicitação para o servidor local
      fetch(serverUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code: script.code
        })
      })
      .then(response => {
        if (!response.ok) {
          throw new Error(`Servidor retornou erro: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        resolve({
          success: true,
          output: data.result || 'Script executado com sucesso no Node.js'
        });
      })
      .catch(error => {
        reject(new Error(`Erro ao executar no servidor Node.js: ${error.message}`));
      });
    });
  });
}